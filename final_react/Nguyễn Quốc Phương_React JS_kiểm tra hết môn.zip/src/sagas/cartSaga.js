import { call, put, takeLatest } from 'redux-saga/effects';
import axios from 'axios';
import {
  fetchProducts,
  fetchProductsSuccess,
  fetchProductsFailure,
} from '../redux/slices/productSlice';

function fetchProductsApi() {
  return axios.get('http://localhost:4000/api/products');
}

function* handleFetchProducts() {
  try {
    const response = yield call(fetchProductsApi);
    yield put(fetchProductsSuccess(response.data));
  } catch (error) {
    yield put(fetchProductsFailure(error.message));
  }
}

export default function* productSaga() {
  yield takeLatest(fetchProducts.type, handleFetchProducts);
}
