import React from 'react';

const ProductDetail = ({
  product,
  quantity,
  onIncrease,
  onDecrease,
  onAddToCart,
}) => {
  if (!product) return <div className="product-detail">Select a product</div>;

  return (
    <div className="product-detail">
      <img src={product.image} alt={product.name} />
      <h2>{product.name}</h2>
      <p>{product.description}</p>
      <div className="quantity-controls">
        <button onClick={onDecrease} disabled={quantity <= 1}>-</button>
        <span>{quantity}</span>
        <button onClick={onIncrease} disabled={quantity >= 99}>+</button>
      </div>
      <p>Total: ${product.price * quantity}</p>
      <button onClick={onAddToCart}>Add to Cart</button>
    </div>
  );
};

export default ProductDetail;
