import React from 'react';

const CartItem = ({ item, onIncrease, onDecrease, onRemove }) => {
  return (
    <div className="cart-item">
      <img src={item.image} alt={item.name} />
      <div>
        <h3>{item.name}</h3>
        <p>{item.description}</p>
        <div className="quantity-controls">
          <button onClick={() => onDecrease(item.id)} disabled={item.quantity <= 1}>-</button>
          <span>{item.quantity}</span>
          <button onClick={() => onIncrease(item.id)} disabled={item.quantity >= 99}>+</button>
        </div>
        <p>${item.price * item.quantity}</p>
      </div>
      <button className="delete-btn" onClick={() => onRemove(item.id)}>🗑️</button>
    </div>
  );
};

export default CartItem;
