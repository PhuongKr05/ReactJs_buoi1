import React from 'react';

const ProductItem = ({ product, onSelect }) => {
  return (
    <div className="product-item">
      <img src={product.image} alt={product.name} />
      <div className="product-info">
        <h3 onClick={() => onSelect(product)}>{product.name}</h3>
        <p>{product.description}</p>
        <strong>${product.price}</strong>
        <button onClick={() => onSelect(product)}>Details</button>
      </div>
    </div>
  );
};

export default ProductItem;
