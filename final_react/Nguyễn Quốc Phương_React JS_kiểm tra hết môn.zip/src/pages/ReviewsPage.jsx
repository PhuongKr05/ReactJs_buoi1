import React from 'react';

const ReviewsPage = () => {
  return (
    <div className="page">
      <h2>Reviews Page</h2>
    </div>
  );
};

export default ReviewsPage;
