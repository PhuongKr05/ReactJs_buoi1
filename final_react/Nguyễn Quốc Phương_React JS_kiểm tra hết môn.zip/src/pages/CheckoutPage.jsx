import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import CartItem from '../components/CartItem';
import { increaseQty, decreaseQty, removeFromCart, clearCart } from '../redux/slices/cartSlice';
import { checkout } from '../redux/slices/cartSlice';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const CheckoutPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const cartItems = useSelector((state) => state.cart.items);

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = cartItems.length > 0 ? 10 : 0;
  const total = subtotal + shipping;

  const handleCheckout = () => {
    const confirmed = window.confirm('Are you sure you want to checkout?');
    if (!confirmed) return;

    dispatch(checkout(cartItems))
      .then(() => {
        toast.success('Payment successful!');
        dispatch(clearCart());
        navigate('/products');
      });
  };

  if (cartItems.length === 0) {
    return (
      <div className="page">
        <h2>Your cart is empty.</h2>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      <div className="cart-items">
        {cartItems.map((item) => (
          <CartItem
            key={item.id}
            item={item}
            onIncrease={() => dispatch(increaseQty(item.id))}
            onDecrease={() => dispatch(decreaseQty(item.id))}
            onRemove={() => dispatch(removeFromCart(item.id))}
          />
        ))}
      </div>
      <div className="summary">
        <p>Subtotal: ${subtotal.toFixed(2)}</p>
        <p>Shipping: ${shipping}</p>
        <h3>Total: ${total.toFixed(2)}</h3>
        <button onClick={handleCheckout} disabled={cartItems.length === 0}>Checkout</button>
        <button onClick={() => navigate('/products')}>Continue Shopping</button>
      </div>
    </div>
  );
};

export default CheckoutPage;
