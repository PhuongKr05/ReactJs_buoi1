import React from 'react';

const HomePage = () => {
  return (
    <div className="page">
      <h2>Home Page</h2>
    </div>
  );
};

export default HomePage;
